<!DOCTYPE>
<html>
    <body>
        <?php
   
        ECHO "Hello World<br>";
        
        ECHO "Hello World<br>";
        
        ECHO "Hello World<br>";
        ?>
        </body>
        </html>