<!DOCTYPE html>
<html>
<body>

<?php
echo "My First PHP script!;"
?>

</body>
</html>
