<?php
    $conn = new mysqli("localhost", "root", "actscdac", "php_sql");

    $sql = "select * from details";
    $array = $conn->query($sql);
    if($array->num_rows > 0){
        while($row = $array->fetch_assoc()){
            echo "name : ".$row['name']."     email : ".$row['email']."<br>";
        }
    }
?>