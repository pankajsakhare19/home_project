<?php
    $file = fopen("file.txt", "r");
    echo "File contents are : <br><br>";
    echo fread($file, filesize("file.txt"));
    fclose($file);
    echo "<br><br><a href='index.html'>Back to Home</a>";
?>