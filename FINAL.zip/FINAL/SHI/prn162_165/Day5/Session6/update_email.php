<?php
    $conn = new mysqli("localhost", "root", "actscdac", "php_sql");

    $nm = $_GET['name'];
    $sql = "select name from details where name='$nm'";
    if($conn->query($sql)->num_rows == 1){
        echo "<form action='update_email2.php' method='GET'>";
        echo "<input type='name' name='name' value='$nm' readonly>";
        echo "<input type='email' name='email' placeholder='Enter New Email'>";
        echo "<input type='submit' value='Update Email'>";
        echo "</form>";
    }
    else{
        echo "Invalid User Name..!! <a href='update.php'>Go Back</a>";
    } 
?>