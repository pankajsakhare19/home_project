<?php
    $conn = new mysqli("localhost", "root", "actscdac", "php_sql");

    // $nm = $_GET['name'];
    // $sql = "select name from details where name='$nm'";

    // if($conn->query($sql)->num_rows == 1){
        echo "<form action='update_email.php' method='GET'>";
        echo "<input type='text' name='name' placeholder='Enter Name'>";
        echo "<input type='submit' value='Update'>";
        echo "</form>";
    // }
?>