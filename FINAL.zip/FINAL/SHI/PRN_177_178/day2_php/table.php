<?php
$servername="localhost";
$username="root";
$password="actscdac";
$dbname="php_Data";

$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error)
{
    die("Connection Failed: ".$conn->connect_error);
}
$sql="create table student(id int(6) unsigned auto_increment primary key,
firstname varchar(30) not null,
lastname varchar(30) not null,
email varchar(50))";

if($conn->query($sql)==TRUE)
{
    echo "table created successfully";
}
else
{
    echo "failed" . $conn->error;
}
$conn->close();
?>