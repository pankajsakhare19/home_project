
$(document).ready(function()
{   
    $("#submit").click(function()
    {
        var movieName = $("#movieName").val();
        var moviePrice = $("#moviePrice").val();
        var releaseDate = $("#releaseDate").val();
        var bookingDate = $("#bookingDate").val();

        var dataString = 'name='+ movieName + '&price='+ moviePrice + '&release='+ releaseDate + '&booking='+ bookingDate;

        if(movieName==''||moviePrice==''||releaseDate==''||bookingDate=='')
        {
            alert("Please Enter Movie Details");
        }
        else if( bookingDate < releaseDate)
        {
            alert("Invalid Date for Movie Booking");
        }
        else
        {
            $.ajax
            ({
                type: "POST",
                url: "./process/process.php",
                data: dataString,
                cache: false,
                success: function(result)
                {
                    alert("Ticket has been Booked Succesfully");
                    alert(result);
                    location.href = "./"
                }
            });
        }
        return false;        
    });
});