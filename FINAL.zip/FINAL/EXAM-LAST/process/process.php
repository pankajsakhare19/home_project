<?php

include_once 'dbconnect.php';

$movieName = $_POST['name'];
$moviePrice = $_POST['price'];
$releaseDate = $_POST['release'];
$bookingDate = $_POST['booking'];

if(isset($movieName))
{
	$bookingID = "MOV".rand(10000,99999);    
	
    if(mysqli_query($connect,"INSERT INTO booking (bookingId,name,price,releaseDate,bookingDate) VALUES ('$bookingID','$movieName','$moviePrice','$releaseDate','$bookingDate')"))
	{		
	    echo "Your Booking ID is: ".$bookingID." for the Show on ".$bookingDate;
	}
	else
	{
	    echo 'Unable to Book Movie Ticket!'. mysqli_error($connect);
	}
}
else
{
	echo 'Unable to Book Movie Ticket! Please check details'. mysqli_error($connect);
}
?>